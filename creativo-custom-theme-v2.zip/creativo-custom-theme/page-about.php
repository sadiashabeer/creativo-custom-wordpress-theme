<?php
/* Template Name: About */
get_header(); ?>
<section class="page-hero"><div class="container"><h1>About Us</h1><p>Home → About Us</p></div></section>
<section class="section"><div class="container about-wrap"><div class="about-image"></div><div><div class="eyebrow">Who We Are</div><h2>We Are a Creative Design & Development Agency</h2><p>We are a team of passionate designers, developers and digital strategists. We love what we do and we do it with passion.</p><div class="checks"><div class="check">High Quality Work</div><div class="check">Expert Team</div><div class="check">On-Time Delivery</div><div class="check">Innovative Solutions</div><div class="check">Client Satisfaction</div><div class="check">24/7 Support</div></div></div></div>
<div class="container stats"><div class="stat"><strong>5+</strong>Years Experience</div><div class="stat"><strong>120+</strong>Projects Completed</div><div class="stat"><strong>80+</strong>Happy Clients</div><div class="stat"><strong>15+</strong>Team Members</div></div></section>
<?php get_footer(); ?>
