document.addEventListener('DOMContentLoaded',function(){
 const toggle=document.querySelector('.menu-toggle');
 const nav=document.querySelector('.main-nav');
 if(toggle && nav){toggle.addEventListener('click',()=>nav.classList.toggle('open'));}
 document.querySelectorAll('.newsletter').forEach(f=>f.addEventListener('submit',e=>e.preventDefault()));
 document.querySelectorAll('.form-card form').forEach(f=>f.addEventListener('submit',e=>{e.preventDefault(); alert('Thank you! Please connect this form to your preferred form service or WordPress handler.');}));
});