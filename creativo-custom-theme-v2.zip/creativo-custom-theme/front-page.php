<?php get_header(); ?>
<section class="hero"><div class="container"><div class="hero-content">
 <div class="eyebrow">Welcome to Creativo</div>
 <h1>We Build Digital Solutions That <span>Grow</span> Your Business</h1>
 <p>We are a creative team of designers, developers and strategists helping brands create amazing digital experiences.</p>
 <a class="btn" href="<?php echo home_url('/projects/'); ?>">Explore Our Work →</a>
 <a class="btn btn-outline" href="<?php echo home_url('/contact/'); ?>">Contact Us</a>
</div></div></section>

<section class="section"><div class="container">
 <div class="section-head"><div class="eyebrow">What We Do</div><h2>Our Services</h2><p>Everything you need to build, launch and grow a strong digital presence.</p></div>
 <div class="grid grid-4">
 <?php $services=array('Web Development','WordPress Development','UI/UX Design','Digital Marketing'); foreach($services as $s): ?>
 <div class="card"><div class="icon">✦</div><h3><?php echo $s; ?></h3><p>Modern, responsive and conversion-focused solutions tailored to your business.</p></div>
 <?php endforeach; ?>
 </div>
</div></section>

<section class="section" style="background:#f7faf8"><div class="container about-wrap">
 <div class="about-image"></div><div><div class="eyebrow">Who We Are</div><h2>Creative Design & Development Agency</h2><p>We combine strategy, design and technology to create digital products that look great and perform even better.</p>
 <div class="checks"><div class="check">High Quality Work</div><div class="check">Expert Team</div><div class="check">On-Time Delivery</div><div class="check">Client Satisfaction</div></div>
 <a class="btn" href="<?php echo home_url('/about/'); ?>">Learn More →</a></div>
</div></section>

<section class="section projects"><div class="container">
 <div class="section-head"><div class="eyebrow">Our Recent Work</div><h2>Our Projects</h2><p>Selected digital experiences created for ambitious brands.</p></div>
 <div class="grid grid-3">
 <?php for($i=1;$i<=6;$i++): ?><article class="card project-card"><div class="project-img" style="background-image:url('https://picsum.photos/seed/creativo<?php echo $i; ?>/900/600')"></div><div class="project-body"><h3>Creative Project <?php echo $i; ?></h3><p>Web Development</p></div></article><?php endfor; ?>
 </div>
</div></section>

<section class="section"><div class="container">
 <div class="section-head"><div class="eyebrow">From Our Blog</div><h2>Latest Articles</h2></div>
 <div class="grid grid-3"><?php $q=new WP_Query(array('posts_per_page'=>3)); if($q->have_posts()): while($q->have_posts()): $q->the_post(); ?>
 <article class="card blog-card"><?php if(has_post_thumbnail()) the_post_thumbnail('large'); ?><div class="meta"><?php echo get_the_date(); ?></div><h3><?php the_title(); ?></h3><p><?php echo wp_trim_words(get_the_excerpt(),20); ?></p><a class="read-more" href="<?php the_permalink(); ?>">Read More →</a></article>
 <?php endwhile; wp_reset_postdata(); else: ?><article class="card"><h3>10 WordPress Tips to Speed Up Your Website</h3><p>Create useful blog posts from WordPress admin.</p></article><article class="card"><h3>How Good Design Improves User Experience</h3><p>Share design insights with your audience.</p></article><article class="card"><h3>The Future of Web Development</h3><p>Publish the latest development trends.</p></article><?php endif; ?></div>
</div></section>

<section class="section"><div class="container cta"><div><h2>Have a Project in Mind?</h2><p>Let's work together and build something amazing.</p></div><a class="btn" href="<?php echo home_url('/contact/'); ?>">Let's Talk →</a></div></section>
<?php get_footer(); ?>
