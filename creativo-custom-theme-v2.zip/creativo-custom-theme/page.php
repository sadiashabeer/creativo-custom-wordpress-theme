<?php get_header(); ?>
<section class="page-hero"><div class="container"><h1><?php the_title(); ?></h1><p>Home → <?php the_title(); ?></p></div></section>
<main class="section"><div class="container">
<?php while(have_posts()): the_post(); the_content(); endwhile; ?>
</div></main>
<?php get_footer(); ?>
