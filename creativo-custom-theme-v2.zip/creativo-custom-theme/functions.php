<?php
if (!defined('ABSPATH')) exit;
require_once get_template_directory() . '/inc/customizer.php';
function creativo_setup(){
 add_theme_support('title-tag'); add_theme_support('post-thumbnails');
 add_theme_support('html5',array('search-form','comment-form','comment-list','gallery','caption','style','script'));
 add_theme_support('custom-logo',array('height'=>60,'width'=>220,'flex-height'=>true,'flex-width'=>true));
 add_theme_support('align-wide'); add_theme_support('responsive-embeds'); add_theme_support('editor-styles');
 add_theme_support('wp-block-styles'); add_theme_support('appearance-tools'); add_theme_support('custom-spacing'); add_theme_support('border');
 register_nav_menus(array('primary'=>'Primary Menu','footer'=>'Footer Menu')); add_editor_style('assets/css/editor-style.css');
}
add_action('after_setup_theme','creativo_setup');
function creativo_widgets_init(){
 register_sidebar(array('name'=>'Main Sidebar','id'=>'sidebar-1','before_widget'=>'<section id="%1$s" class="widget %2$s card">','after_widget'=>'</section>','before_title'=>'<h3 class="widget-title">','after_title'=>'</h3>'));
 register_sidebar(array('name'=>'Footer Newsletter','id'=>'footer-newsletter','before_widget'=>'<div class="footer-widget">','after_widget'=>'</div>','before_title'=>'<h3>','after_title'=>'</h3>'));
}
add_action('widgets_init','creativo_widgets_init');
function creativo_assets(){
 wp_enqueue_style('bootstrap','https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css',array(),'5.3.3');
 wp_enqueue_style('creativo-style',get_stylesheet_uri(),array('bootstrap'),'2.0.0');
 wp_enqueue_script('bootstrap','https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js',array(),'5.3.3',true);
 wp_enqueue_script('creativo-js',get_template_directory_uri().'/assets/js/main.js',array(),'2.0.0',true);
 wp_add_inline_style('creativo-style',':root{--green:'.esc_attr(get_theme_mod('creativo_primary_color','#16a34a')).';--dark:'.esc_attr(get_theme_mod('creativo_dark_color','#071017')).';--radius:'.absint(get_theme_mod('creativo_radius',18)).'px}');
}
add_action('wp_enqueue_scripts','creativo_assets');
function creativo_menu_fallback(){
 echo '<ul class="main-nav"><li><a href="'.esc_url(home_url('/')).'">Home</a></li><li><a href="'.esc_url(home_url('/about/')).'">About</a></li><li><a href="'.esc_url(home_url('/services/')).'">Services</a></li><li><a href="'.esc_url(home_url('/projects/')).'">Projects</a></li><li><a href="'.esc_url(home_url('/blog/')).'">Blog</a></li><li><a href="'.esc_url(home_url('/contact/')).'">Contact</a></li></ul>';
}
