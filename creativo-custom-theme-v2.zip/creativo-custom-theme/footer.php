<?php if (!defined('ABSPATH')) exit; ?>
<footer class="site-footer">
 <div class="container">
  <div class="footer-grid">
   <div>
    <div class="logo"><span class="logo-mark">C</span>Creativo</div>
    <p>We build digital solutions that help businesses grow, engage audiences and succeed online.</p>
    <h3>Follow Us</h3>
    <p><a href="#">Facebook</a> · <a href="#">Instagram</a> · <a href="#">LinkedIn</a></p>
   </div>
   <div><h3>Quick Links</h3><?php if(has_nav_menu('footer')) wp_nav_menu(array('theme_location'=>'footer','container'=>false,'menu_class'=>'footer-menu')); else: ?><ul><li><a href="<?php echo home_url('/'); ?>">Home</a></li><li><a href="<?php echo home_url('/about/'); ?>">About Us</a></li><li><a href="<?php echo home_url('/services/'); ?>">Services</a></li><li><a href="<?php echo home_url('/projects/'); ?>">Projects</a></li><li><a href="<?php echo home_url('/blog/'); ?>">Blog</a></li><li><a href="<?php echo home_url('/contact/'); ?>">Contact</a></li></ul></div>
   <div><h3>Our Services</h3><ul><li>Web Development</li><li>WordPress Development</li><li>UI/UX Design</li><li>E-commerce Solutions</li><li>SEO Optimization</li><li>Maintenance & Support</li></ul></div>
   <div><h3>Newsletter</h3><p>Subscribe for the latest updates.</p><form class="newsletter"><input type="email" placeholder="Your Email"><button type="submit">Subscribe</button></form></div>
  </div>
  <div class="footer-bottom"><span>© <?php echo date('Y'); ?> Creativo. All Rights Reserved.</span><span>Privacy Policy &nbsp; | &nbsp; Terms & Conditions</span></div>
 </div>
</footer>
<?php wp_footer(); ?>
</body></html>
