<?php
/* Template Name: Projects */
get_header(); ?>
<section class="page-hero"><div class="container"><h1>Our Projects</h1><p>Home → Projects</p></div></section>
<section class="section projects"><div class="container"><div class="filters"><span class="filter active">All</span><span class="filter">Web Development</span><span class="filter">UI/UX Design</span><span class="filter">Branding</span><span class="filter">E-commerce</span></div><div class="grid grid-3">
<?php for($i=1;$i<=6;$i++): ?><article class="card project-card"><div class="project-img" style="background-image:url('https://picsum.photos/seed/project<?php echo $i; ?>/900/600')"></div><div class="project-body"><h3><?php echo esc_html(array('Digital Agency Website','E-commerce Platform','Finance Mobile App','Corporate Branding','Analytics Dashboard','Real Estate Website')[$i-1]); ?></h3><p>Creative digital solution</p></div></article><?php endfor; ?>
</div></div></section>
<?php get_footer(); ?>
