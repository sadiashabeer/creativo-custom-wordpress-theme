<?php
/* Template Name: Services */
get_header(); ?>
<section class="page-hero"><div class="container"><h1>Our Services</h1><p>Home → Services</p></div></section>
<section class="section"><div class="container"><div class="section-head"><div class="eyebrow">What We Offer</div><h2>Our Services</h2><p>Innovative digital solutions to help your business grow.</p></div><div class="grid grid-4">
<?php foreach(array('Web Development','WordPress Development','UI/UX Design','Digital Marketing','E-commerce Solutions','SEO Optimization','Maintenance & Support','Business Consulting') as $s): ?><div class="card"><div class="icon">✦</div><h3><?php echo esc_html($s); ?></h3><p>Professional, scalable and user-focused solutions built around your goals.</p></div><?php endforeach; ?>
</div></div></section>
<?php get_footer(); ?>
