<?php
/* Template Name: Contact */
get_header(); ?>
<section class="page-hero"><div class="container"><h1>Contact Us</h1><p>Home → Contact</p></div></section>
<section class="section"><div class="container contact-grid">
<div class="card"><h2>Get In Touch</h2><div class="info-list"><div class="info-item"><strong>Location</strong>123 Street, New York, NY 10001, USA</div><div class="info-item"><strong>Email</strong>hello@creativo.com</div><div class="info-item"><strong>Phone</strong>+1 (212) 456-7890</div><div class="info-item"><strong>Working Hours</strong>Mon - Fri: 9:00 AM - 6:00 PM</div></div></div>
<div class="card form-card"><h2>Send a Message</h2><form><input placeholder="Your Name"><input type="email" placeholder="Your Email"><input placeholder="Subject"><textarea placeholder="Your Message"></textarea><button class="btn" type="submit">Send Message →</button></form></div>
<div class="map"></div>
</div></section>
<section class="section"><div class="container cta"><div><h2>Let's Start Your Project</h2><p>Ready to bring your ideas to life?</p></div><a class="btn" href="mailto:hello@creativo.com">Get Started →</a></div></section>
<?php get_footer(); ?>
