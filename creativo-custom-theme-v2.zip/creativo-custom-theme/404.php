<?php get_header(); ?>
<main class="not-found"><div class="container"><div class="eyebrow">Page Error</div><h1>404</h1><h2>Oops! Page Not Found</h2><p>The page you're looking for doesn't exist or has been moved.</p><a class="btn" href="<?php echo home_url('/'); ?>">← Back to Home</a></div></main>
<?php get_footer(); ?>
