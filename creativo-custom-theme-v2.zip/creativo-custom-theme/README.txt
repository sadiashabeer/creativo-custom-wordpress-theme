CREATIVO CUSTOM WORDPRESS THEME — TASK READY

✓ From-scratch custom theme (no existing WordPress theme)
✓ Custom Header, Footer, Sidebar and Page Templates
✓ Dynamic wp_nav_menu() navigation with Primary + Footer menus
✓ Customizer: primary color, dark/footer color, font family, card radius/layout
✓ Responsive Bootstrap 5 + custom CSS
✓ JavaScript / Bootstrap interactions
✓ Gutenberg-compatible editor styles and block supports
✓ Wide/aligned blocks, responsive embeds, spacing, border and appearance tools
✓ Featured images, custom logo, blog archive, single post and 404
✓ Widget areas for Main Sidebar and Footer Newsletter

INSTALL:
1. Appearance → Themes → Add New → Upload Theme.
2. Upload ZIP and activate.
3. Create Home, About, Services, Projects, Blog, Contact pages.
4. Select the matching custom templates for About/Services/Projects/Contact.
5. Settings → Reading → set Home as static Front Page and Blog as Posts Page.
6. Appearance → Menus → assign Primary Menu and Footer Menu.
7. Appearance → Widgets → configure sidebar if desired.
8. Appearance → Customize → Creativo Colors/Layout/Typography.

Some demo images are remote placeholders; replace them with your own licensed/local images for final submission.
