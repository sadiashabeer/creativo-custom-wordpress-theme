<?php
if (!defined('ABSPATH')) exit;
function creativo_customize_register($wp_customize) {
 $wp_customize->add_section('creativo_colors',array('title'=>'Creativo Colors','priority'=>30));
 foreach(array('creativo_primary_color'=>array('Primary Green','#16a34a'),'creativo_dark_color'=>array('Dark / Footer Color','#071017')) as $id=>$v){
  $wp_customize->add_setting($id,array('default'=>$v[1],'sanitize_callback'=>'sanitize_hex_color'));
  $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize,$id,array('label'=>$v[0],'section'=>'creativo_colors')));
 }
 $wp_customize->add_section('creativo_layout',array('title'=>'Creativo Layout','priority'=>31));
 $wp_customize->add_setting('creativo_radius',array('default'=>18,'sanitize_callback'=>'absint'));
 $wp_customize->add_control('creativo_radius',array('label'=>'Card Corner Radius (px)','section'=>'creativo_layout','type'=>'range','input_attrs'=>array('min'=>0,'max'=>40,'step'=>1)));
 $wp_customize->add_section('creativo_typography',array('title'=>'Creativo Typography','priority'=>32));
 $wp_customize->add_setting('creativo_font',array('default'=>'Inter','sanitize_callback'=>'sanitize_text_field'));
 $wp_customize->add_control('creativo_font',array('label'=>'Font Family','section'=>'creativo_typography','type'=>'select','choices'=>array('Inter'=>'Inter','Arial'=>'Arial','Georgia'=>'Georgia','system-ui'=>'System UI')));
}
add_action('customize_register','creativo_customize_register');
function creativo_customizer_css(){ $font=get_theme_mod('creativo_font','Inter'); echo '<style>body{font-family:'.esc_attr($font).',system-ui,sans-serif}</style>'; }
add_action('wp_head','creativo_customizer_css');
